import pandas as pd

data = pd.read_csv("project.csv")