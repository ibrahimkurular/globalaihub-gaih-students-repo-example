#Explain your work

#Question 1
for x in range(a):
	print(a)